STIGA HOCKEY PLAYER by MAVRIS on Thingiverse: https://www.thingiverse.com/thing:6898521

Summary:
Print seperate player and stick.